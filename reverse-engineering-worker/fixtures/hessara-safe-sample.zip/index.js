export function add(left, right) { return left + right; }
export const label = "HESSARA safe sample";
